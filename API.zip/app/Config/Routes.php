<?php namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php'))
{
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

$routes->post("api/register", "Api::createUser");

$routes->post("api/login", "Api::validateUser");

$routes->get("api/userdata", "Api::userDetails");



/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
/*

$routes->get('/', 'Home::index');
$routes->get('Categories', 'Categories::index');
$routes->get('Dashboards', 'Dashboards::index');
$routes->get('Profiles', 'Profiles::index');

$routes->match(['get','post'],'Contents/index', 'Contents::add');

$routes->match(['get','post'],'Configurations/index', 'Configurations::index');

$routes->match(['get','post'],'Profiles/changepass', 'Profiles::changepass');
$routes->match(['get','post'],'Profiles/changephoto', 'Profiles::changephoto');
$routes->match(['get','post'],'Profiles/edit', 'Profiles::edit');

$routes->get('Users', 'Users::index');
$routes->match(['get','post'],'users/add', 'Users::add');
$routes->match(['get','post'],'users/profile/(:num)', 'Users::profile/$1');
$routes->post('users/edit/(:num)', 'Users::edit/$1');





/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php'))
{
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
